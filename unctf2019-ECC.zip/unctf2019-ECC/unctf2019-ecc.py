from Crypto.Cipher import AES
import base64


key = bytes('????????'.ljust(16,' '))
aes = AES.new(key,AES.MODE_ECB)

# encrypt
plain_text = bytes('??????????'.ljust(16,' '))
text_enc = aes.encrypt(plain_text)
text_enc_b64 = base64.b64encode(text_enc)
print(text_enc_b64)

#output：/cM8Nx+iAidmt6RiqX8Vww==

E=EllipticCurve(GF(15424654874903),[16546484,4548674875])
G=E(6478678675, 5636379357093)
k=???????
K=k*G
#K=(2854873820564,9226233541419)

aes_key=???????
x=aes_key
M=E.lift_x(x)

r=?????????
C1=M+r*K
x1,y1=C1.xy()
C2=r*G
x2,y2=C2.xy()
print 'C1(%d,%d),C2(%d,%d)'%(x1,y1,x2,y2)

#output：
C1(6860981508506,1381088636252),C2(1935961385155,8353060610242)
